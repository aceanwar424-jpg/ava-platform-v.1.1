@echo off
cd /d "%~dp0connector"
node ava-connector.js
pause
